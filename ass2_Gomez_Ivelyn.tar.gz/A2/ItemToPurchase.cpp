#include<iostream>
#include<string>
#include <stdio.h>
#include "ItemToPurchase.h"
using namespace std;
ItemToPurchase::ItemToPurchase(){
	name = "NoName";
	price = 0.0;
	quantity = 0;
}

ItemToPurchase::ItemToPurchase(std::string fName, double nPrice, int nQuantity ){
	name = fName;
	price = nPrice;
	quantity = nQuantity;
}
void ItemToPurchase::SetName(std::string lname){
	name = lname;
}
void ItemToPurchase::SetPrice(double lprice){
	price = lprice;
}
void ItemToPurchase::SetQuantity(int lQuantity){
	quantity = lQuantity;
}
std::ostream & operator << (std::ostream & out, const ItemToPurchase & item){
	out<<item.name<<" " <<std::to_string(item.quantity)<<" @ $" <<std::to_string(item.price);

	return out;
}
std::string ItemToPurchase::GetName(){
	return name;
}
double ItemToPurchase::GetPrice(){
	return price;
}
int ItemToPurchase::GetQuantity(){
	return quantity;
}



