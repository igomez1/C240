#include <stdio.h>
#include <iostream>
#include <vector>
#include <string.h>
#include <sstream>
#include <cctype>
#include <fstream>
#include <stdlib.h>
#include <ctype.h>
#include <cstring>
#include <locale>

#include "ShoppingCart.h"

using namespace std;
string getUserInput();
//input: none
//output: returns string entered by user
//side effects: prompts user and reads input
vector <string> read_file(string name);
//input: a string
//output: returns a vector of strings
//side effects: none
vector <string> words(vector<string> file);
//input: vector of strings containing each line of the file
//output: vector of strings containing each word per line
//side effects: none
void disasFile(vector<string> words, LinkedList bask);
//input: vector of strings and LinkedList to manipulate
//output: none
//side effects: reads file and manipulates the linked list per line based on file input
int main (){
	LinkedList basket = LinkedList();

	string input = getUserInput();
	vector <string> read = read_file(input);
	

	vector <string> wordz = words(read);
	disasFile(wordz, basket);	
		
}
string getUserInput(){
	string line;
	cout << "Enter file name: "<<endl;
	getline(cin, line);
	return line;
}
vector <string> read_file(string name){
	
	vector<string> my_arr;

	ifstream my_file(name);
	string line;
	if(my_file.is_open()){
		while(getline(my_file, line)){
			string new_line;
			new_line = line + "\n";
			my_arr.push_back(new_line);
		}
		my_file.close();
		return my_arr;
	}
	else{
		cout <<"Unable to open file, does not exist."<<endl;
		exit (EXIT_FAILURE);
	}
}
vector <string> words(vector<string> file){
	vector <string> res ; 
	string s;

	for (int i = 0; i < file.size(); i ++){
		s = file.at(i);

		istringstream iss(s);
		while(iss>>s){
			res.push_back(s);
		}
	}
	return res;

}
void disasFile(vector<string> words, LinkedList bask){
	for(int i = 0; i <words.size();  i ++){
		if(words.at(i) == "A"){
			int n = i+1;
			int x = i + 2;// quantity
			int y = i + 3; // price
			int z = i + 4; //pos

			size_t offset = 0;

			double nPrice1 = stod(words.at(y), &offset);

			int nQuantity1 = atoi(words.at(x).c_str());

			if (isdigit(words.at(z).at(0))== true){
				int pos = atoi (words.at(z).c_str());
				ItemToPurchase item = ItemToPurchase(words.at(n), nPrice1, nQuantity1);
				bool appendish = bask.insert(pos, item);	
			}
			else{

			ItemToPurchase item = ItemToPurchase(words.at(n), nPrice1, nQuantity1);
			bool appended = bask.append(item);
			}
		}
		else if(words.at(i) == "R"){
			int y = i + 1;
			int x = atoi(words.at(y).c_str());
		       	bask.remove(x); //need pos

		}
		else if(words.at(i) == "D"){
			int y = i +1;

			int pos = atoi(words.at(y).c_str());
			
			ItemToPurchase gotten = bask.retrieve(pos);
			if (gotten.GetName() == "NoName"){
				
			}else{
			cout << gotten << endl;
			}
		}
		else if(words.at(i)=="DA"){
			if (bask.getLength() == 0){
				cout <<"There are no items"<<endl;
			}else{	
			for (int i = 1; i <= bask.getLength(); i++){
				ItemToPurchase list = bask.retrieve(i);
				cout << i<<". " <<list << endl;	
			}
			}
		}
		else if(words.at(i)=="DC"){
			int z = i+1;
			if (bask.getLength() == 0){
				cout << "Total cost is $0"<<endl;
			}
			else{
				if (isdigit(words.at(z).at(0))== true){
					int pos = atoi (words.at(z).c_str());
					ItemToPurchase item = bask.retrieve(pos);
					if (item.GetName() == "NoName"){
					}
					else{
					double cost = item.GetPrice() *	item.GetQuantity(); 
					cout << item.GetName() <<" "<< item.GetQuantity() << " @" <<cost <<endl;	
					}
				}
				else{
					double total = 0;
					for (int i = 1 ; i <= bask.getLength(); i ++){
			     			total += (bask.retrieve(i).GetPrice() * bask.retrieve(i).GetQuantity());
					}
				cout <<"Total Cost is $"<<total <<endl;
				total = 0;
				}
			}

		}
		else if(words.at(i)=="DN"){
			if (bask.getLength() == 0 ){
				cout <<"There are no items" <<endl;
			}
			else{
			cout <<"There are "<<bask.getLength()<<" items."<< endl;
			}
		}




	}

}


