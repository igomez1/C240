#include <stdio.h>
#include <iostream>
#include <string>
#include "LinkedList.h"
#include "ItemToPurchase.h"
using namespace std;
LinkedList::LinkedList(){
	head = nullptr;
	tail = nullptr;
	size = 0;

}

bool LinkedList::isEmpty() const{
	if (size== 0){
		return true;
	}
	else{
		return false;
	}
}
int LinkedList::getLength() const{
	return size;
}
bool LinkedList::append(const ItemType & newEntry ){
	
	node *tmp = new node;
	tmp->data = newEntry;
	tmp->next = NULL;
	if (head == NULL){
		head = tmp;
		tail = tmp;
		size++;
		return true;
	}
	else{
		tail->next = tmp;
		tail = tail->next;
		size++;
		return true;
	}	
}
bool LinkedList::insert(int newPos, const ItemType & newEntry){
	
	node *insert = new node;
	insert->data = newEntry;
	node *tmp = new node; 
	tmp = head;
	int currPos = 1; 

	if (newPos > size || newPos == 0 || newPos < 0){
		cout <<"Out of bounds insertion!"<<endl;
		return false;
	}
	if (newPos == 1){
		insert->next = tmp;
		head = insert;
		size++;
		return true;
	}
	else if (tmp!= NULL){
		while(tmp->next != NULL && currPos != newPos-1){
			tmp = tmp->next;
			currPos++;
		}
		insert->next = tmp->next;
		tmp->next = insert;
		size++;
		return true;
	}


}
bool LinkedList::remove(int pos){
	node *temp = new node;	
	temp = head;
	if (pos > size || pos == 0 || pos < 0 ){
		cout << "Position it out of bounds!"<<endl;
		return false;
	}

	if (pos == 1 && temp!= NULL){//inserting at head 
		head = temp->next;
		delete(temp);
		size--;
		if(temp == NULL ){
			tail = NULL;
		}

		return true;
	}
	else{	
	for(int i = 2; temp->next!=NULL && i<pos-1; i++){
		temp = temp->next;
	}
	temp->next = temp->next->next;
	size--;
	return true;
	}

}
ItemType LinkedList::retrieve (int position)const{
	node *current = new node ;
	current = head;
	if (position == 0 || position > size || position < 0){
		ItemToPurchase item = ItemToPurchase();
		cout << "Position is out of bounds" <<endl;
		return item;
	}
	if (position ==1){
		return head->data;
	}	
	current = current->next;
	int i = 2;
	while (i < position ){
		if (current!= nullptr){
			current = current->next; 
			i++;
		}
		else{
			cout <<"Position is out of bounds!"<<endl;
			
		}
	}
	return current->data;


}

