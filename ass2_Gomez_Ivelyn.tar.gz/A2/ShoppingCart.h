#ifndef Shopping_Cart_
#define Shopping_Cart_

#include "LinkedList.h"
#include "ItemToPurchase.h"

class ShoppingCart : public LinkedList {

	private:
		LinkedList cart;
	public:
		bool insert(int newPos, const ItemType & newEntry);
		bool remove (int pos);
		bool append(const ItemType & newEntry);
		ItemType retrieve(int position) const;
		int getLength() const;
		void printList();
		friend std::ostream& operator<< (std::ostream & out, const ItemToPurchase &item);
		double GetPrice();
};



#endif
