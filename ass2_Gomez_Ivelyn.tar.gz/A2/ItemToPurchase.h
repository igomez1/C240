#ifndef ITEMTOPURCHASE_H
#define ITEMTOPURCHASE_H
#include <string>
class ItemToPurchase
{
	private:
		std::string name;
		double price;
		int quantity;
	public:
		ItemToPurchase();
		ItemToPurchase(std::string nName, double nPrice, int nQuantity);
		void SetName(std::string lname);
		void SetPrice(double lPrice);
		void SetQuantity(int lQuantity);
		double GetPrice();
		std::string GetName();
		int GetQuantity();	
		void GetItemInfo();
		friend std::ostream& operator<< (std::ostream & out, const ItemToPurchase &item);
			
};
#endif
