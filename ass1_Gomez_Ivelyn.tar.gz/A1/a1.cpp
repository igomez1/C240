#include <stdio.h>
#include <iostream>
#include <vector>
#include <string.h>
#include <sstream>
#include <fstream>
#include <cctype>
using namespace std;
int nonBlankLines(vector <string> arr);
//input: vector of strings
//output: returns integer of nonBlankLines
//side effects: none
string getUserInput();
//input: none
//output: returns string entered by user
//side effects: prompts user and reads input
vector<string> read_file(string name);
//input: a string
//output: returns a vector of strings
//side effects: none
int countWords (vector <string> arr);
//input: a vector of strings
//output: returns int of totalWords
//side effects: calls checkAlphas
int checkAlphas(int x, string s);
//input: a string of words and int of total words
//output: returns int of corrected totalWords
//side effects: none
double avgWords(int x, int y);
//input: int for totalwords and int for number of nonBlank lines 
//output: returns int of average words/nonblank line
//side effects: none
int totalC (vector<string> arr);
//input: vector of strings
//output: returns int of total alphas
//side effects: none
double avgC(int c, int w);
//input: int for total chars and int for total words
//output: returns avg num of alphas per word
//side effects: none
int main(){
	//vector <string> arr;
	string name = getUserInput();
	vector <string> arr = read_file(name);
	int non = nonBlankLines(arr);
	cout << "Number of non blank lines: " << non <<endl;
	int words = countWords(arr);
	double avg = avgWords(words, non);
	cout << "Avg num of words/non blank line: " << avg << endl;
	int totC = totalC(arr);
	double c = avgC(totC, words);
	cout << "Avg num of alphas per word: " << c << endl;

}
string getUserInput(){
	string line;
	cout << "Enter file name: "<<endl;
	getline(cin, line);
	return line;
}
vector<string> read_file(string name){
     int counter = 0;
     vector<string> my_arr;

     ifstream my_file(name);
     string line;
     if(my_file.is_open()){
	while(getline(my_file, line))
     	{
	string new_line;
	new_line = line + "\n";
        my_arr.push_back(new_line);
	counter += 1;

	}
	my_file.close();

	return my_arr;
     }
     else{
     	cout<< "Unable to open file, does not exist."<<endl;
	exit (EXIT_FAILURE);
     }
}
int nonBlankLines (vector <string> arr){
	int count = 0;
	int blank = 0;
	for(int i = 0 ; i < arr.size(); i++){
		if(arr.at(i).length() == 1 ){
			blank++;
		}	
		else{
			count++;
		}
	}
	if (count == 0 ){
		cout << "Empty file" << endl;
		exit (EXIT_FAILURE);
	}
	return count ;
}
int countWords (vector <string> arr){
	vector <string> res;
	int words= 0;
	int fini;
	string s;

	for (int i = 0 ; i < arr.size(); i++){
		s = arr.at(i);
		
		istringstream iss(s);
		while (iss>>s){	
		res.push_back(s);
		words++;
		}
	}

	
	for (int i = 0 ; i < res.size(); i ++){
		fini = checkAlphas(words, res.at(i));
	
	}
	return fini;
}
int checkAlphas(int x, string s){
	int b = 0 ;//false
	int alphas = 0;
	for (int i = 0 ; i < s.length(); i ++){
		if (isalpha(s.at(i))){
			b = 1; 
		}
	
	}
	if (b == 0){
		x--;
	}
	return x;
}
double avgWords(int x, int y){
	double avg; 
	avg =(double)x/ (double)y;
	return avg;
}
int totalC (vector<string> arr){
	string s;
	int c = 0;
	vector <string> res;
	for (int i = 0 ; i < arr.size(); i++){
		s = arr.at(i);
		
		istringstream iss(s);
		while (iss>>s){	
		res.push_back(s);
		}
	}
	for (int j = 0 ; j < res.size(); j++){
		for (int k = 0 ; k < res.at(j).length(); k ++){
			if (isalpha(res.at(j).at(k)) ){
				c++;
			}			
		}
	}
	return c; 

}


double avgC (int totalC, int totalWords){
	double avgC;
	avgC = (double )totalC/ (double)totalWords;
	return avgC;

}



